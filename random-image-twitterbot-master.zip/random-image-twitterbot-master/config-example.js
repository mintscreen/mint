var config = {};

config.twitter = {
  consumer_key: 'CONSUMERKEY',
  consumer_secret: 'CONSUMERSECRET',
  access_token: 'ACCESSTOKEN',
  access_token_secret: 'ACCESSTOKENSECRET'
}

module.exports = config;
