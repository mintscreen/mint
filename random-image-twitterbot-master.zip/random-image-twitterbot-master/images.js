var images = [
  {
    file: 'baby-elephant.jpg',
    source: 'https://www.hd-wallpapersdownload.com/desktop-free-baby-animal-wallpaper/'
  },
  {
    file: 'baby-panda.jpg',
    source: 'https://www.ordissinaute.fr/diaporamas/2016-05-09-beaux-bebes'
  },
  {
    file: 'kitten.jpg',
    source: 'https://pxhere.com/fi/photo/1124650'
  },
  {
    file: 'puppy.jpg',
    source: 'http://www.publicdomainpictures.net/view-image.php?image=10863&picture=baby-cockamo-in-yard'
  },
  {
    file: 'two-kittens.jpg',
    source: 'http://maxpixel.freegreatpicture.com/Animals-Cute-Kitten-Funny-Little-Cats-88152'
  }
];

module.exports = images;
